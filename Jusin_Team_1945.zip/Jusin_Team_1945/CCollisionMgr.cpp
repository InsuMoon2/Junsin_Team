#include "pch.h"
#include "CCollisionMgr.h"

#include "CItem.h"

void CCollisionMgr::Collision_Rect(list<CObj*> _Dst, list<CObj*> _Src)
{
	RECT	rcCol{};

	for (auto& Dst : _Dst)
	{
		for (auto& Src : _Src)
		{
			if (Dst->Get_Owner() == Src)
				continue;

			if (IntersectRect(&rcCol, Dst->Get_Rect(), Src->Get_Rect()))
			{
				Dst->Set_Dead();
				Src->Set_Dead();
			}
		}
	}

}

void CCollisionMgr::Collision_Circle(list<CObj*> _bullet, list<CObj*> _monster)
{
	for (auto& Dst : _bullet)
	{
		for (auto& Src : _monster)
		{
			// Dst(�Ѿ�)�� �����ڰ� Src(����)�� ������ �浹 �˻� ����
			if (Dst->Get_Owner() == Src)
				continue;

			if (Dst->Get_Owner() == Src->Get_Owner())
				continue;

			if (Check_Circle(Dst, Src))
			{
				Src->Set_Hp(Src->Get_Hp() - Dst->Get_Attack());
				Dst->Set_Dead();
			}
		}
	}
}

void CCollisionMgr::Collision_Circle(list<CObj*> _bullet, CObj* _HitObject)
{
	for (auto& bullet : _bullet)
	{
		if (bullet->Get_Owner() == _HitObject)
			continue;

		if (Check_Circle(bullet, _HitObject))
		{
			_HitObject->Set_Hp(_HitObject->Get_Hp() - bullet->Get_Attack());
			bullet->Set_Dead();
		}
	}
}

bool CCollisionMgr::Check_Circle(CObj* _Dst, CObj* _Src)
{
	float	fWidth = fabsf(_Dst->Get_Info().fX - _Src->Get_Info().fX);
	float	fHeight = fabsf(_Dst->Get_Info().fY - _Src->Get_Info().fY);

	float	fDiagonal = sqrtf(fWidth * fWidth + fHeight * fHeight);

	float	fRadius = (_Dst->Get_Info().fCX + _Src->Get_Info().fCX) * 0.5f;

	return fRadius >= fDiagonal;
}

void CCollisionMgr::Collision_Item(CObj* _pPlayer, list<CObj*> _pItem)
{
	if (!_pPlayer) return;

	for (auto& item : _pItem)
	{
		RECT	rcCol{};

		if (IntersectRect(&rcCol, _pPlayer->Get_Rect(), item->Get_Rect()))
		{
			if (auto pItem = dynamic_cast<CItem*>(item)) 
			{
				pItem->Use_Item(_pPlayer);
				item->Set_Dead();
			}
		}
	}

}