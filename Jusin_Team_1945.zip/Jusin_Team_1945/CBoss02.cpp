#include "pch.h"
#include "CObj.h"
#include "CBoss02.h"
#include "AbstractFactory.h"
#include "CBullet.h"
#include "CBossBullet.h"
#include "CUIMgr.h"
#include "CSceneMgr.h"


CBoss02::CBoss02(): m_dwTime(GetTickCount()), m_fBarrel_Speed(0), m_bHp(false), m_dwTime01(GetTickCount()), m_dwTime02(GetTickCount()), m_dwTime03(GetTickCount())
{

	ZeroMemory(&m_tHpUi, sizeof(m_tHpUi));
}

CBoss02::~CBoss02()
{
	Release();
}

void CBoss02::Initialize()
{
	m_tInfo = { WINCX / 2, -10, 100, 100 };
	m_fSpeed = 7.f;

	m_iMaxHp = 500;
	m_iHp = 500;

	m_tHpUi = { 50,50,WINCX - 50,70 };

	m_iBarrel_Len = 100;

	m_fAngle = 90.f;
	m_fBarrel_Speed = 10.f;

	__super::Update_Rect();

}

int CBoss02::Update()
{
	//if (m_bDead )//&& (GetAsyncKeyState(VK_RETURN) & 0x0001))
	//{
	//	CSceneMgr::GetInstance()->ChangeScene(ESceneType::Stage01);
	//	Initialize();
	//}

	if (m_bDead == true)
		return OBJ_DEAD;
	
	if (m_tInfo.fY <= 150)
	{
		m_tInfo.fY += m_fSpeed;
	}
	else if (m_tInfo.fY >= 150)
		m_bHp = true;

	
	m_tBarrel_Pos.X = m_tInfo.fX + (m_iBarrel_Len * cosf(m_fAngle * (PI / 180)));
	m_tBarrel_Pos.Y = m_tInfo.fY + (m_iBarrel_Len * sinf(m_fAngle * (PI / 180)));

	if (m_bHp == true)
	{
		attackTime1 = Mgr1.GetCurrentTimeCount(2);

		m_tInfo.fX -= m_fSpeed;
	}
	
	if (m_dwTime + 1200 < GetTickCount())
	{
		if(m_iHp > m_iMaxHp * 0.5f)
		{
			Attack_Circular();
		}
		m_dwTime = GetTickCount();
	}

	if (m_dwTime01 + 100 < GetTickCount())
	{
		if (m_iHp <= m_iMaxHp * 0.5f)
		{

			Attack_Cos();
		}

		m_dwTime01 = GetTickCount();
	}

	if (m_dwTime02 + 1000 < GetTickCount())
	{

		if (m_iHp <= m_iMaxHp * 0.5f)
		{

			Attack_Guided();
		}

		m_dwTime02 = GetTickCount();
	}

	if (m_dwTime03 + 5000 < GetTickCount())
	{
		Attack_Around();
		
		m_dwTime03 = GetTickCount();
	}

	__super::Update_Rect();
	//Key_Input();  

	return 0;
}

void CBoss02::Late_Update()
{
	if (m_iHp <= 0)
	{
		m_bDead = true;
	}

	if (m_tRect.left <= 0 || m_tRect.right >= WINCX)
	{
		m_fSpeed *= -1;
	}

}

void CBoss02::Render(HDC hDC)
{
	Rectangle(hDC, m_tRect.left, m_tRect.top, m_tRect.right, m_tRect.bottom);
	Rectangle(hDC, m_tRect.left + 10, m_tRect.top + 10, m_tRect.right - 10, m_tRect.bottom - 10);
	
	MoveToEx(hDC, m_tInfo.fX, m_tInfo.fY, NULL);
	LineTo(hDC, m_tBarrel_Pos.X, m_tBarrel_Pos.Y);

	// hp ui
	{
		if (m_bHp == true)
		{
			CUIMgr::Get_Instance()->Render_HP(hDC, this);

		}
	}


}

void CBoss02::Release()
{

}



void CBoss02::Key_Input()
{
	if (GetAsyncKeyState('8'))
	{
		Attack_Guided();

	}
}

void CBoss02::Attack_Circular()
{
	float tmp_Angle ;

	if (m_tTarget)
	{

		float x = m_tTarget->Get_Info().fX - m_tInfo.fX;
		float y = m_tTarget->Get_Info().fY - m_tInfo.fY;

		tmp_Angle = acos(x / sqrtf(pow(x, 2) + pow(y, 2)));

		if (y < 0)
			tmp_Angle = 2 * PI - tmp_Angle;

		m_fAngle = tmp_Angle * (180.0 / PI);

		for (int i = -20; i < 21; i += 10)
		{
		CObj* tmp1 = Create_BossBullet(m_fAngle +i , Circular);
		tmp1->Set_Pos(m_tBarrel_Pos.X-i, m_tBarrel_Pos.Y);
		m_pBullet->push_back(tmp1);


		}
	}
}

void CBoss02::Attack_Cos()
{

	m_iBarrel_Len = 200;

	double m = normalize(m_tInfo.fX, 0 + m_tInfo.fCX*.5f, WINCX- m_tInfo.fCX * .5f);
	double resize_X = rescale(m, 135,45);
	
	m_fAngle = resize_X;

	if (m_fAngle >= 135 || m_fAngle <= 45)
	{
		m_fBarrel_Speed *= -1;
	}
	
	
	m_pBullet->push_back(Create_BossBullet(m_fAngle, Cos));

}

void CBoss02::Attack_Guided()
{
	CObj* bullet = Create_BossBullet(m_fAngle, Guided);
	if (m_tTarget)
	{
		bullet->Set_Target(this->m_tTarget);
	}
	m_pBullet->push_back(bullet);

}

void CBoss02::Attack_Around()
{
	for (int i = 0; i < 360; i += 20)
	{
		CObj* tmp1 = Create_BossBullet(i, Around);
		m_pBullet->push_back(tmp1);

	}
}

