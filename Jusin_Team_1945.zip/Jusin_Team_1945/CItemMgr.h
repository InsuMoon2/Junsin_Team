#pragma once
class CItemMgr
{
};

